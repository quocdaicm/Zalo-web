# Zalo Web (iOS)

Ứng dụng iOS 17+ mở `chat.zalo.me` trong WebView, mỗi tài khoản một vùng lưu đăng nhập riêng.

## Chạy thử (cần Mac + Xcode 15+)

Cách 1, dùng XcodeGen:
    brew install xcodegen
    cd ZaloWebSwitcher && xcodegen && open ZaloWebSwitcher.xcodeproj

Cách 2, thủ công: Xcode > New Project > iOS App (SwiftUI, tên ZaloWebSwitcher, iOS 17),
xóa file mẫu, kéo 4 file trong `Sources/` vào dự án.

Sau đó chọn Team trong Signing & Capabilities và chạy lên iPhone thật.
Đăng nhập bằng mã QR hoặc số điện thoại như trên trình duyệt.

## Giới hạn
- Không có thông báo đẩy; chỉ nhận tin khi ứng dụng đang mở.
- Mỗi tài khoản chỉ có một phiên web cùng lúc (quy tắc của Zalo).
- Zalo có thể thay đổi hoặc chặn trang web bất cứ lúc nào.

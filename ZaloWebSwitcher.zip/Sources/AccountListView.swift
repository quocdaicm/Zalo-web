import SwiftUI

struct AccountListView: View {
    @EnvironmentObject var store: AccountStore
    @State private var showAdd = false
    @State private var newName = ""
    @State private var renaming: Account?
    @State private var renameText = ""
    @State private var deleting: Account?

    var body: some View {
        NavigationStack {
            List {
                ForEach(store.accounts) { account in
                    NavigationLink(value: account) {
                        Label(account.name, systemImage: "person.crop.circle")
                    }
                    .swipeActions {
                        Button("Xóa", role: .destructive) { deleting = account }
                        Button("Đổi tên") { renameText = account.name; renaming = account }
                            .tint(.blue)
                    }
                }
                .onMove(perform: store.move)
            }
            .overlay {
                if store.accounts.isEmpty {
                    ContentUnavailableView("Chưa có tài khoản",
                        systemImage: "person.crop.circle.badge.plus",
                        description: Text("Bấm + để thêm tài khoản Zalo đầu tiên."))
                }
            }
            .navigationTitle("Zalo Web")
            .navigationDestination(for: Account.self) { AccountWebView(account: $0) }
            .toolbar {
                ToolbarItem(placement: .topBarLeading) { EditButton() }
                ToolbarItem(placement: .topBarTrailing) {
                    Button { newName = ""; showAdd = true } label: { Image(systemName: "plus") }
                }
            }
            .alert("Thêm tài khoản", isPresented: $showAdd) {
                TextField("Tên gợi nhớ", text: $newName)
                Button("Thêm") { store.add(name: newName) }
                Button("Hủy", role: .cancel) {}
            }
            .alert("Đổi tên", isPresented: Binding(get: { renaming != nil }, set: { if !$0 { renaming = nil } })) {
                TextField("Tên", text: $renameText)
                Button("Lưu") { if let a = renaming { store.rename(a, to: renameText) } }
                Button("Hủy", role: .cancel) {}
            }
            .confirmationDialog("Xóa tài khoản này khỏi ứng dụng?",
                isPresented: Binding(get: { deleting != nil }, set: { if !$0 { deleting = nil } }),
                titleVisibility: .visible) {
                Button("Xóa và đăng xuất", role: .destructive) {
                    if let a = deleting { Task { await store.remove(a) } }
                }
            } message: {
                Text("Chỉ xóa phiên đăng nhập lưu trong ứng dụng này. Tài khoản Zalo của bạn không bị ảnh hưởng.")
            }
        }
    }
}

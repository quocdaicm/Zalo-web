import SwiftUI

struct AccountListView: View {
    @EnvironmentObject var store: AccountStore
    @State private var showAdd = false
    @State private var newName = ""
    @State private var renaming: Account?
    @State private var renameText = ""
    @State private var deleting: Account?
    @State private var opened: Account?

    private let columns = [GridItem(.adaptive(minimum: 150), spacing: 14)]

    var body: some View {
        NavigationStack {
            ScrollView {
                if store.accounts.isEmpty {
                    emptyState
                } else {
                    LazyVGrid(columns: columns, spacing: 14) {
                        ForEach(store.accounts) { account in
                            card(account)
                        }
                        addCard
                    }
                    .padding(16)
                }
            }
            .background(Color(.systemGroupedBackground))
            .navigationTitle("Tài khoản")
            .alert("Thêm tài khoản", isPresented: $showAdd) {
                TextField("Tên gợi nhớ", text: $newName)
                Button("Thêm") { store.add(name: newName) }
                Button("Hủy", role: .cancel) {}
            }
            .alert("Đổi tên", isPresented: Binding(get: { renaming != nil }, set: { if !$0 { renaming = nil } })) {
                TextField("Tên", text: $renameText)
                Button("Lưu") { if let a = renaming { store.rename(a, to: renameText) } }
                Button("Hủy", role: .cancel) {}
            }
            .confirmationDialog("Xóa tài khoản này khỏi ứng dụng?",
                isPresented: Binding(get: { deleting != nil }, set: { if !$0 { deleting = nil } }),
                titleVisibility: .visible) {
                Button("Xóa và đăng xuất", role: .destructive) {
                    if let a = deleting { Task { await store.remove(a) } }
                }
            } message: {
                Text("Chỉ xóa phiên đăng nhập lưu trong ứng dụng này. Tài khoản Zalo của bạn không bị ảnh hưởng.")
            }
            .fullScreenCover(item: $opened) { WebScreen(start: $0) }
        }
    }

    private func card(_ account: Account) -> some View {
        Button { opened = account } label: {
            VStack(spacing: 12) {
                Avatar(account: account, size: 64)
                Text(account.name)
                    .font(.headline)
                    .foregroundStyle(.primary)
                    .lineLimit(1)
            }
            .frame(maxWidth: .infinity)
            .padding(.vertical, 22)
            .background(Color(.secondarySystemGroupedBackground), in: RoundedRectangle(cornerRadius: 20, style: .continuous))
            .overlay(alignment: .topLeading) {
                StatusIcon(status: store.status[account.id]).padding(12)
            }
            .overlay(alignment: .topTrailing) {
                UnreadBadge(count: store.unread[account.id] ?? 0).padding(12)
            }
        }
        .buttonStyle(.plain)
        .contextMenu {
            Button { renameText = account.name; renaming = account } label: { Label("Đổi tên", systemImage: "pencil") }
            Button(role: .destructive) { deleting = account } label: { Label("Xóa", systemImage: "trash") }
        }
    }

    private var addCard: some View {
        Button { newName = ""; showAdd = true } label: {
            VStack(spacing: 12) {
                Image(systemName: "plus")
                    .font(.system(size: 26, weight: .semibold))
                    .foregroundStyle(.tint)
                    .frame(width: 64, height: 64)
                    .background(Color.accentColor.opacity(0.12), in: Circle())
                Text("Thêm").font(.headline).foregroundStyle(.tint)
            }
            .frame(maxWidth: .infinity)
            .padding(.vertical, 22)
            .overlay(RoundedRectangle(cornerRadius: 20, style: .continuous)
                .strokeBorder(Color.accentColor.opacity(0.35), style: StrokeStyle(lineWidth: 1.5, dash: [6])))
        }
        .buttonStyle(.plain)
    }

    private var emptyState: some View {
        VStack(spacing: 16) {
            Image(systemName: "bubble.left.and.bubble.right.fill")
                .font(.system(size: 56))
                .foregroundStyle(.tint)
            Text("Chưa có tài khoản").font(.title3.bold())
            Text("Thêm tài khoản để đăng nhập và chuyển qua lại nhanh.")
                .multilineTextAlignment(.center)
                .foregroundStyle(.secondary)
            Button { newName = ""; showAdd = true } label: {
                Label("Thêm tài khoản", systemImage: "plus")
                    .padding(.horizontal, 8)
            }
            .buttonStyle(.borderedProminent)
            .controlSize(.large)
        }
        .padding(32)
        .frame(maxWidth: .infinity)
        .padding(.top, 80)
    }
}

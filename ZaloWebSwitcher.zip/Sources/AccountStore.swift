import Foundation
import WebKit
import UserNotifications
import Network

/// Một tài khoản = một tên hiển thị + một UUID. UUID này chọn vùng lưu dữ liệu web riêng
/// (cookie, localStorage, IndexedDB), nên mỗi tài khoản đăng nhập độc lập với nhau.
enum AccountStatus { case normal, offline, signedOut }

struct Account: Identifiable, Codable, Hashable {
    var id: UUID = UUID()
    var name: String
}

@MainActor
final class AccountStore: ObservableObject {
    @Published private(set) var accounts: [Account] = []
    private let key = "accounts.v1"
    private var webViews: [UUID: WKWebView] = [:]
    private var titleObservers: [UUID: NSKeyValueObservation] = [:]

    /// Số tin chưa đọc của từng tài khoản, đọc từ tiêu đề trang Zalo Web (ví dụ "(3) Zalo").
    @Published private(set) var unread: [UUID: Int] = [:]
    var totalUnread: Int { unread.values.reduce(0, +) }

    /// Trạng thái kết nối và phiên đăng nhập của từng tài khoản (không có mục = bình thường).
    @Published private(set) var status: [UUID: AccountStatus] = [:]
    private var delegates: [UUID: WebDelegate] = [:]
    private var seenSignedIn: Set<UUID> = []
    private var loginSignals: [UUID: Int] = [:]
    private let monitor = NWPathMonitor()
    private var online = true
    private var timer: Timer?

    /// Dấu hiệu trang đang ở màn hình đăng nhập. Nếu Zalo đổi giao diện thì chỉnh ở đây.
    private static let loginCheckJS = """
    (function(){
      var t=((document.body&&document.body.innerText)||'').slice(0,3000).toLowerCase();
      if(document.readyState!=='complete'||t.length<50){return null;}
      return location.hostname.indexOf('id.zalo.me')>=0
        || t.indexOf('mã qr')>=0
        || (t.indexOf('đăng nhập')>=0 && t.indexOf('số điện thoại')>=0);
    })()
    """

    static let zaloURL = URL(string: "https://chat.zalo.me")!

    init() {
        if let data = UserDefaults.standard.data(forKey: key),
           let list = try? JSONDecoder().decode([Account].self, from: data) {
            accounts = list
        }
        if let ids = UserDefaults.standard.stringArray(forKey: "seenSignedIn.v1") {
            seenSignedIn = Set(ids.compactMap(UUID.init(uuidString:)))
        }
        monitor.pathUpdateHandler = { [weak self] path in
            let on = path.status == .satisfied
            Task { @MainActor in self?.networkChanged(on) }
        }
        monitor.start(queue: DispatchQueue(label: "net.monitor"))
        timer = Timer.scheduledTimer(withTimeInterval: 20, repeats: true) { [weak self] _ in
            Task { @MainActor in self?.checkSessions() }
        }
        UNUserNotificationCenter.current().requestAuthorization(options: [.badge]) { _, _ in }
        // Mở sẵn mọi tài khoản để số tin chưa đọc cập nhật cả khi chưa bấm vào.
        for account in accounts { _ = webView(for: account) }
    }

    static func unreadCount(fromTitle title: String?) -> Int {
        guard let title,
              let r = title.range(of: #"^\s*[\(\[]\s*(\d+)\s*\+?\s*[\)\]]"#, options: .regularExpression),
              let n = Int(title[r].filter(\.isNumber))
        else { return 0 }
        return n
    }

    private func setStatus(_ st: AccountStatus, for id: UUID) {
        if st == .normal { status[id] = nil } else { status[id] = st }
    }

    private func reloadOrLoad(_ id: UUID) {
        guard let web = webViews[id] else { return }
        if web.url == nil { web.load(URLRequest(url: Self.zaloURL)) } else { web.reload() }
    }

    private func networkChanged(_ on: Bool) {
        let was = online
        online = on
        guard on, !was else { return }
        for (id, st) in status where st == .offline { reloadOrLoad(id) }
    }

    fileprivate func loadFailed(_ id: UUID, _ error: Error) {
        let e = error as NSError
        guard e.domain == NSURLErrorDomain, e.code != NSURLErrorCancelled else { return }
        setStatus(.offline, for: id)
        Task { @MainActor in
            try? await Task.sleep(for: .seconds(10))
            if self.status[id] == .offline, self.online { self.reloadOrLoad(id) }
        }
    }

    fileprivate func loadSucceeded(_ id: UUID) {
        if status[id] == .offline { setStatus(.normal, for: id) }
    }

    fileprivate func contentProcessTerminated(_ id: UUID) { reloadOrLoad(id) }

    private func checkSessions() {
        for (id, web) in webViews where web.url != nil && status[id] != .offline {
            web.evaluateJavaScript(Self.loginCheckJS) { [weak self] result, _ in
                guard let self, let loginScreen = result as? Bool else { return }
                Task { @MainActor in self.sessionCheck(id, loginScreen: loginScreen) }
            }
        }
    }

    private func sessionCheck(_ id: UUID, loginScreen: Bool) {
        if loginScreen {
            loginSignals[id, default: 0] += 1
            // Cần hai lần liên tiếp để tránh báo nhầm.
            if loginSignals[id]! >= 2, seenSignedIn.contains(id) {
                seenSignedIn.remove(id)
                persistSeen()
                setStatus(.signedOut, for: id)
            }
        } else {
            loginSignals[id] = 0
            if !seenSignedIn.contains(id) { seenSignedIn.insert(id); persistSeen() }
            if status[id] == .signedOut { setStatus(.normal, for: id) }
        }
    }

    private func persistSeen() {
        UserDefaults.standard.set(seenSignedIn.map(\.uuidString), forKey: "seenSignedIn.v1")
    }

    func relogin(_ account: Account) {
        webViews[account.id]?.load(URLRequest(url: Self.zaloURL))
    }

    private func setUnread(_ n: Int, for id: UUID) {
        if n == 0 { unread[id] = nil } else { unread[id] = n }
        UNUserNotificationCenter.current().setBadgeCount(totalUnread) { _ in }
    }

    private func save() {
        if let data = try? JSONEncoder().encode(accounts) {
            UserDefaults.standard.set(data, forKey: key)
        }
    }

    func add(name: String) {
        let trimmed = name.trimmingCharacters(in: .whitespacesAndNewlines)
        let account = Account(name: trimmed.isEmpty ? "Tài khoản \(accounts.count + 1)" : trimmed)
        accounts.append(account)
        save()
        _ = webView(for: account)
    }

    func rename(_ account: Account, to name: String) {
        guard let i = accounts.firstIndex(of: account) else { return }
        let trimmed = name.trimmingCharacters(in: .whitespacesAndNewlines)
        if !trimmed.isEmpty { accounts[i].name = trimmed }
        save()
    }

    func move(from: IndexSet, to: Int) {
        accounts.move(fromOffsets: from, toOffset: to)
        save()
    }

    /// Xóa tài khoản và toàn bộ dữ liệu đăng nhập của nó trên máy này.
    func remove(_ account: Account) async {
        webViews[account.id] = nil
        titleObservers[account.id] = nil
        delegates[account.id] = nil
        status[account.id] = nil
        loginSignals[account.id] = nil
        if seenSignedIn.remove(account.id) != nil { persistSeen() }
        setUnread(0, for: account.id)
        accounts.removeAll { $0.id == account.id }
        save()
        try? await WKWebsiteDataStore.remove(forIdentifier: account.id)
    }

    /// WebView được giữ lại để chuyển qua lại giữa các tài khoản không phải tải lại trang.
    func webView(for account: Account) -> WKWebView {
        if let existing = webViews[account.id] { return existing }

        let config = WKWebViewConfiguration()
        config.websiteDataStore = WKWebsiteDataStore(forIdentifier: account.id)
        config.defaultWebpagePreferences.preferredContentMode = .desktop
        config.allowsInlineMediaPlayback = true
        config.mediaTypesRequiringUserActionForPlayback = []

        let view = WKWebView(frame: .zero, configuration: config)
        view.allowsBackForwardNavigationGestures = true
        view.isInspectable = true
        view.customUserAgent =
            "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/17.0 Safari/605.1.15"
        view.load(URLRequest(url: Self.zaloURL))
        webViews[account.id] = view
        let delegate = WebDelegate(store: self, id: account.id)
        delegates[account.id] = delegate
        view.navigationDelegate = delegate
        let id = account.id
        titleObservers[id] = view.observe(\.title, options: [.new]) { [weak self] web, _ in
            let n = Self.unreadCount(fromTitle: web.title)
            Task { @MainActor in self?.setUnread(n, for: id) }
        }
        return view
    }
}

@MainActor
final class WebDelegate: NSObject, WKNavigationDelegate {
    private weak var store: AccountStore?
    private let id: UUID

    init(store: AccountStore, id: UUID) { self.store = store; self.id = id }

    func webView(_ webView: WKWebView, didFailProvisionalNavigation navigation: WKNavigation!, withError error: Error) {
        store?.loadFailed(id, error)
    }
    func webView(_ webView: WKWebView, didFail navigation: WKNavigation!, withError error: Error) {
        store?.loadFailed(id, error)
    }
    func webView(_ webView: WKWebView, didFinish navigation: WKNavigation!) {
        store?.loadSucceeded(id)
    }
    func webViewWebContentProcessDidTerminate(_ webView: WKWebView) {
        store?.contentProcessTerminated(id)
    }
}

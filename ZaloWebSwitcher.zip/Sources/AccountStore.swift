import Foundation
import WebKit

/// Một tài khoản = một tên hiển thị + một UUID. UUID này chọn vùng lưu dữ liệu web riêng
/// (cookie, localStorage, IndexedDB), nên mỗi tài khoản đăng nhập độc lập với nhau.
struct Account: Identifiable, Codable, Hashable {
    var id: UUID = UUID()
    var name: String
}

@MainActor
final class AccountStore: ObservableObject {
    @Published private(set) var accounts: [Account] = []
    private let key = "accounts.v1"
    private var webViews: [UUID: WKWebView] = [:]

    static let zaloURL = URL(string: "https://chat.zalo.me")!

    init() {
        if let data = UserDefaults.standard.data(forKey: key),
           let list = try? JSONDecoder().decode([Account].self, from: data) {
            accounts = list
        }
    }

    private func save() {
        if let data = try? JSONEncoder().encode(accounts) {
            UserDefaults.standard.set(data, forKey: key)
        }
    }

    func add(name: String) {
        let trimmed = name.trimmingCharacters(in: .whitespacesAndNewlines)
        accounts.append(Account(name: trimmed.isEmpty ? "Tài khoản \(accounts.count + 1)" : trimmed))
        save()
    }

    func rename(_ account: Account, to name: String) {
        guard let i = accounts.firstIndex(of: account) else { return }
        let trimmed = name.trimmingCharacters(in: .whitespacesAndNewlines)
        if !trimmed.isEmpty { accounts[i].name = trimmed }
        save()
    }

    func move(from: IndexSet, to: Int) {
        accounts.move(fromOffsets: from, toOffset: to)
        save()
    }

    /// Xóa tài khoản và toàn bộ dữ liệu đăng nhập của nó trên máy này.
    func remove(_ account: Account) async {
        webViews[account.id] = nil
        accounts.removeAll { $0.id == account.id }
        save()
        try? await WKWebsiteDataStore.remove(forIdentifier: account.id)
    }

    /// WebView được giữ lại để chuyển qua lại giữa các tài khoản không phải tải lại trang.
    func webView(for account: Account) -> WKWebView {
        if let existing = webViews[account.id] { return existing }

        let config = WKWebViewConfiguration()
        config.websiteDataStore = WKWebsiteDataStore(forIdentifier: account.id)
        config.defaultWebpagePreferences.preferredContentMode = .desktop
        config.allowsInlineMediaPlayback = true
        config.mediaTypesRequiringUserActionForPlayback = []

        let view = WKWebView(frame: .zero, configuration: config)
        view.allowsBackForwardNavigationGestures = true
        view.isInspectable = true
        view.customUserAgent =
            "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/17.0 Safari/605.1.15"
        view.load(URLRequest(url: Self.zaloURL))
        webViews[account.id] = view
        return view
    }
}

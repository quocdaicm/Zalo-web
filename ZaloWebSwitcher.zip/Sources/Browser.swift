import SwiftUI
import WebKit
import QuickLook

struct FileItem: Identifiable {
    let url: URL
    var id: String { url.path }
}

struct ShareSheet: UIViewControllerRepresentable {
    let items: [Any]
    func makeUIViewController(context: Context) -> UIActivityViewController {
        UIActivityViewController(activityItems: items, applicationActivities: nil)
    }
    func updateUIViewController(_ vc: UIActivityViewController, context: Context) {}
}

struct QuickLookView: UIViewControllerRepresentable {
    let url: URL
    func makeUIViewController(context: Context) -> QLPreviewController {
        let c = QLPreviewController()
        c.dataSource = context.coordinator
        return c
    }
    func updateUIViewController(_ vc: QLPreviewController, context: Context) {}
    func makeCoordinator() -> Coordinator { Coordinator(url: url) }

    final class Coordinator: NSObject, QLPreviewControllerDataSource {
        let url: URL
        init(url: URL) { self.url = url }
        func numberOfPreviewItems(in controller: QLPreviewController) -> Int { 1 }
        func previewController(_ controller: QLPreviewController, previewItemAt index: Int) -> QLPreviewItem { url as NSURL }
    }
}

/// Thông báo nhỏ ở cuối màn hình khi một tệp tải xong hoặc tải lỗi.
struct DownloadToast: ViewModifier {
    @EnvironmentObject var store: AccountStore
    let fromBrowser: Bool
    @State private var share: FileItem?

    func body(content: Content) -> some View {
        content
            .overlay(alignment: .bottom) {
                if let e = store.lastDownload, e.fromBrowser == fromBrowser {
                    HStack(spacing: 10) {
                        Image(systemName: e.url != nil ? "checkmark.circle.fill" : "xmark.octagon.fill")
                            .foregroundStyle(e.url != nil ? Color.green : Color.red)
                        VStack(alignment: .leading, spacing: 2) {
                            Text(e.url != nil ? "Đã tải xong" : "Tải xuống thất bại")
                                .font(.caption).foregroundStyle(.secondary)
                            Text(e.url?.lastPathComponent ?? e.error ?? "").font(.subheadline).lineLimit(1)
                        }
                        Spacer(minLength: 4)
                        if let url = e.url {
                            Button("Lưu / Chia sẻ") { share = FileItem(url: url) }
                                .font(.subheadline.bold())
                        }
                        Button { store.lastDownload = nil } label: { Image(systemName: "xmark") }
                            .foregroundStyle(.secondary)
                    }
                    .padding(12)
                    .background(.regularMaterial, in: RoundedRectangle(cornerRadius: 14, style: .continuous))
                    .padding(.horizontal, 12)
                    .padding(.bottom, 76)
                    .task(id: e.id) {
                        try? await Task.sleep(for: .seconds(10))
                        if store.lastDownload?.id == e.id { store.lastDownload = nil }
                    }
                }
            }
            .sheet(item: $share) { ShareSheet(items: [$0.url]) }
    }
}

extension View {
    func downloadToast(fromBrowser: Bool) -> some View { modifier(DownloadToast(fromBrowser: fromBrowser)) }
}

@MainActor
final class BrowserModel: ObservableObject {
    let web: WKWebView
    private let handler: WebDelegate
    private var observers: [NSKeyValueObservation] = []

    @Published var title = ""
    @Published var url: URL?
    @Published var canGoBack = false
    @Published var canGoForward = false
    @Published var progress = 0.0
    @Published var isLoading = false

    init(store: AccountStore, start: URL?) {
        let config = WKWebViewConfiguration()
        config.allowsInlineMediaPlayback = true
        web = WKWebView(frame: .zero, configuration: config)
        web.allowsBackForwardNavigationGestures = true
        handler = WebDelegate(store: store, id: nil)
        web.navigationDelegate = handler
        web.uiDelegate = handler
        observers = [
            web.observe(\.title, options: [.new]) { [weak self] w, _ in Task { @MainActor in self?.title = w.title ?? "" } },
            web.observe(\.url, options: [.new]) { [weak self] w, _ in Task { @MainActor in self?.url = w.url } },
            web.observe(\.canGoBack, options: [.new]) { [weak self] w, _ in Task { @MainActor in self?.canGoBack = w.canGoBack } },
            web.observe(\.canGoForward, options: [.new]) { [weak self] w, _ in Task { @MainActor in self?.canGoForward = w.canGoForward } },
            web.observe(\.estimatedProgress, options: [.new]) { [weak self] w, _ in Task { @MainActor in self?.progress = w.estimatedProgress } },
            web.observe(\.isLoading, options: [.new]) { [weak self] w, _ in Task { @MainActor in self?.isLoading = w.isLoading } },
        ]
        if let start { web.load(URLRequest(url: start)) }
    }

    /// Nhận địa chỉ web hoặc từ khóa tìm kiếm.
    func go(_ text: String) {
        let t = text.trimmingCharacters(in: .whitespacesAndNewlines)
        guard !t.isEmpty else { return }
        if let u = URL(string: t), let s = u.scheme?.lowercased(), s == "http" || s == "https" {
            web.load(URLRequest(url: u))
        } else if !t.contains(" "), t.contains("."), let u = URL(string: "https://" + t) {
            web.load(URLRequest(url: u))
        } else if var c = URLComponents(string: "https://www.google.com/search") {
            c.queryItems = [URLQueryItem(name: "q", value: t)]
            if let u = c.url { web.load(URLRequest(url: u)) }
        }
    }
}

struct BrowserScreen: View {
    @Environment(\.dismiss) private var dismiss
    @EnvironmentObject var store: AccountStore
    @StateObject private var model: BrowserModel
    @State private var text = ""
    @FocusState private var focused: Bool

    init(target: BrowserTarget, store: AccountStore) {
        _model = StateObject(wrappedValue: BrowserModel(store: store, start: target.url))
        _text = State(initialValue: target.url?.absoluteString ?? "")
    }

    var body: some View {
        VStack(spacing: 0) {
            HStack(spacing: 10) {
                Button { dismiss() } label: { Image(systemName: "xmark").font(.system(size: 16, weight: .semibold)) }
                TextField("Nhập địa chỉ hoặc từ khóa", text: $text)
                    .textInputAutocapitalization(.never)
                    .autocorrectionDisabled()
                    .keyboardType(.webSearch)
                    .focused($focused)
                    .submitLabel(.go)
                    .onSubmit { model.go(text); focused = false }
                    .padding(.horizontal, 12).frame(height: 36)
                    .background(Color(.tertiarySystemFill), in: Capsule())
                Button {
                    if model.isLoading { model.web.stopLoading() } else { model.web.reload() }
                } label: { Image(systemName: model.isLoading ? "xmark.circle" : "arrow.clockwise") }
            }
            .padding(.horizontal, 16).frame(height: 48)
            .background(.bar)

            ProgressView(value: model.isLoading ? model.progress : 0)
                .opacity(model.isLoading ? 1 : 0)
                .frame(height: 2)

            ZStack {
                WebContainer(webView: model.web)
                if model.url == nil {
                    Text("Nhập địa chỉ hoặc từ khóa để bắt đầu.")
                        .foregroundStyle(.secondary)
                        .allowsHitTesting(false)
                }
            }

            HStack {
                Button { model.web.goBack() } label: { Image(systemName: "chevron.left") }
                    .disabled(!model.canGoBack)
                Spacer()
                Button { model.web.goForward() } label: { Image(systemName: "chevron.right") }
                    .disabled(!model.canGoForward)
                Spacer()
                if let url = model.url {
                    ShareLink(item: url) { Image(systemName: "square.and.arrow.up") }
                    Spacer()
                    Button { UIApplication.shared.open(url) } label: { Image(systemName: "safari") }
                } else {
                    Image(systemName: "square.and.arrow.up").foregroundStyle(.tertiary)
                    Spacer()
                    Image(systemName: "safari").foregroundStyle(.tertiary)
                }
            }
            .font(.system(size: 19))
            .padding(.horizontal, 28).frame(height: 48)
            .background(.bar)
        }
        .onChange(of: model.url) { _, new in
            if !focused, let new { text = new.absoluteString }
        }
        .downloadToast(fromBrowser: true)
    }
}

struct DownloadsView: View {
    @Environment(\.dismiss) private var dismiss
    @State private var files: [URL] = []
    @State private var preview: FileItem?
    @State private var share: FileItem?

    var body: some View {
        NavigationStack {
            List {
                ForEach(files, id: \.self) { url in
                    Button { preview = FileItem(url: url) } label: {
                        VStack(alignment: .leading, spacing: 3) {
                            Text(url.lastPathComponent).lineLimit(2)
                            Text(info(url)).font(.caption).foregroundStyle(.secondary)
                        }
                    }
                    .foregroundStyle(.primary)
                    .swipeActions {
                        Button("Xóa", role: .destructive) { delete(url) }
                        Button("Lưu / Chia sẻ") { share = FileItem(url: url) }.tint(.blue)
                    }
                }
            }
            .scrollContentBackground(.hidden)
            .background(AppBackground())
            .overlay {
                if files.isEmpty {
                    ContentUnavailableView("Chưa có tệp tải về", systemImage: "tray",
                        description: Text("Tệp tải từ Zalo và trình duyệt sẽ nằm ở đây."))
                }
            }
            .navigationTitle("Tải xuống")
            .navigationBarTitleDisplayMode(.inline)
            .toolbar { ToolbarItem(placement: .topBarTrailing) { Button("Xong") { dismiss() } } }
            .onAppear { files = Downloads.list() }
            .sheet(item: $preview) { QuickLookView(url: $0.url).ignoresSafeArea() }
            .sheet(item: $share) { ShareSheet(items: [$0.url]) }
        }
    }

    private func info(_ url: URL) -> String {
        let v = try? url.resourceValues(forKeys: [.fileSizeKey, .contentModificationDateKey])
        let size = ByteCountFormatter.string(fromByteCount: Int64(v?.fileSize ?? 0), countStyle: .file)
        let date = v?.contentModificationDate?.formatted(date: .abbreviated, time: .shortened) ?? ""
        return "\(size) · \(date)"
    }

    private func delete(_ url: URL) {
        try? FileManager.default.removeItem(at: url)
        files = Downloads.list()
    }
}

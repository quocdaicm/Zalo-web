import SwiftUI

extension Account {
    private static let palette: [Color] = [
        Color(red: 0.25, green: 0.28, blue: 0.90), Color(red: 0.00, green: 0.66, blue: 0.67),
        Color(red: 0.93, green: 0.40, blue: 0.35), Color(red: 0.96, green: 0.65, blue: 0.14),
        Color(red: 0.55, green: 0.36, blue: 0.96), Color(red: 0.18, green: 0.69, blue: 0.40),
    ]
    var color: Color {
        let n = id.uuid.0 &+ id.uuid.5 &+ id.uuid.11
        return Self.palette[Int(n) % Self.palette.count]
    }
    var initial: String { String(name.trimmingCharacters(in: .whitespaces).first ?? "?").uppercased() }
}

struct Avatar: View {
    let account: Account
    var size: CGFloat = 48
    var body: some View {
        Text(account.initial)
            .font(.system(size: size * 0.42, weight: .semibold, design: .rounded))
            .foregroundStyle(.white)
            .frame(width: size, height: size)
            .background(LinearGradient(colors: [account.color, account.color.opacity(0.75)],
                                       startPoint: .topLeading, endPoint: .bottomTrailing), in: Circle())
    }
}

struct UnreadBadge: View {
    let count: Int
    var body: some View {
        if count > 0 {
            Text(count > 99 ? "99+" : "\(count)")
                .font(.system(size: 12, weight: .bold))
                .foregroundStyle(.white)
                .padding(.horizontal, 6)
                .frame(minWidth: 20, minHeight: 20)
                .background(Color.red, in: Capsule())
        }
    }
}

struct StatusIcon: View {
    let status: AccountStatus?
    var body: some View {
        switch status {
        case .offline:
            Image(systemName: "wifi.slash").font(.system(size: 11, weight: .bold)).foregroundStyle(.white)
                .padding(5).background(Color.gray, in: Circle())
        case .signedOut:
            Image(systemName: "exclamationmark").font(.system(size: 11, weight: .bold)).foregroundStyle(.white)
                .padding(5).background(Color.orange, in: Circle())
        default:
            EmptyView()
        }
    }
}

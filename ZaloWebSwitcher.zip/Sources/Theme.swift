import SwiftUI

extension Account {
    private static let palette: [Color] = [
        Color(red: 0.25, green: 0.28, blue: 0.90), Color(red: 0.00, green: 0.66, blue: 0.67),
        Color(red: 0.93, green: 0.40, blue: 0.35), Color(red: 0.96, green: 0.65, blue: 0.14),
        Color(red: 0.55, green: 0.36, blue: 0.96), Color(red: 0.18, green: 0.69, blue: 0.40),
    ]
    var color: Color {
        let n = id.uuid.0 &+ id.uuid.5 &+ id.uuid.11
        return Self.palette[Int(n) % Self.palette.count]
    }
    var initial: String { String(name.trimmingCharacters(in: .whitespaces).first ?? "?").uppercased() }
}

struct Avatar: View {
    let account: Account
    var size: CGFloat = 48
    var body: some View {
        Text(account.initial)
            .font(.system(size: size * 0.42, weight: .semibold, design: .rounded))
            .foregroundStyle(.white)
            .frame(width: size, height: size)
            .background(LinearGradient(colors: [account.color, account.color.opacity(0.75)],
                                       startPoint: .topLeading, endPoint: .bottomTrailing), in: Circle())
    }
}

struct UnreadBadge: View {
    let count: Int
    var body: some View {
        if count > 0 {
            Text(count > 99 ? "99+" : "\(count)")
                .font(.system(size: 12, weight: .bold))
                .foregroundStyle(.white)
                .padding(.horizontal, 6)
                .frame(minWidth: 20, minHeight: 20)
                .background(Color.red, in: Capsule())
        }
    }
}

struct StatusIcon: View {
    let status: AccountStatus?
    var body: some View {
        switch status {
        case .offline:
            Image(systemName: "wifi.slash").font(.system(size: 11, weight: .bold)).foregroundStyle(.white)
                .padding(5).background(Color.gray, in: Circle())
        case .signedOut:
            Image(systemName: "exclamationmark").font(.system(size: 11, weight: .bold)).foregroundStyle(.white)
                .padding(5).background(Color.orange, in: Circle())
        default:
            EmptyView()
        }
    }
}

/// Nền của ứng dụng: màu nền mềm với ba vệt sáng mờ, tự đổi theo chế độ sáng hoặc tối.
struct AppBackground: View {
    @Environment(\.colorScheme) private var scheme

    var body: some View {
        let dark = scheme == .dark
        ZStack {
            (dark ? Color(red: 0.04, green: 0.05, blue: 0.13) : Color(red: 0.95, green: 0.96, blue: 1.0))
            GeometryReader { g in
                let w = g.size.width, h = g.size.height
                Circle()
                    .fill(Color(red: 0.00, green: 0.78, blue: 0.75).opacity(dark ? 0.32 : 0.34))
                    .frame(width: w * 0.95)
                    .blur(radius: 80)
                    .offset(x: -w * 0.35, y: -h * 0.10)
                Circle()
                    .fill(Color(red: 0.25, green: 0.28, blue: 0.90).opacity(dark ? 0.45 : 0.28))
                    .frame(width: w * 1.1)
                    .blur(radius: 90)
                    .offset(x: w * 0.30, y: h * 0.62)
                Circle()
                    .fill(Color(red: 0.62, green: 0.38, blue: 0.98).opacity(dark ? 0.28 : 0.20))
                    .frame(width: w * 0.6)
                    .blur(radius: 70)
                    .offset(x: w * 0.55, y: h * 0.12)
            }
        }
        .ignoresSafeArea()
    }
}

extension View {
    /// Thẻ kính mờ đặt trên AppBackground.
    func glassCard(cornerRadius: CGFloat = 20) -> some View {
        self
            .background(.regularMaterial, in: RoundedRectangle(cornerRadius: cornerRadius, style: .continuous))
            .overlay(RoundedRectangle(cornerRadius: cornerRadius, style: .continuous)
                .strokeBorder(Color.white.opacity(0.18), lineWidth: 1))
            .shadow(color: .black.opacity(0.08), radius: 12, y: 4)
    }
}

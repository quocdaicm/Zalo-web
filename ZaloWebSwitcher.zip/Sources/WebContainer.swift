import SwiftUI
import WebKit

struct WebContainer: UIViewRepresentable {
    let webView: WKWebView
    func makeUIView(context: Context) -> WKWebView { webView }
    func updateUIView(_ uiView: WKWebView, context: Context) {}
}

struct AccountWebView: View {
    @EnvironmentObject var store: AccountStore
    let account: Account

    var body: some View {
        let web = store.webView(for: account)
        WebContainer(webView: web)
            .ignoresSafeArea(.container, edges: .bottom)
            .navigationTitle(account.name)
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .topBarTrailing) {
                    Button {
                        if web.url == nil { web.load(URLRequest(url: AccountStore.zaloURL)) }
                        else { web.reload() }
                    } label: { Image(systemName: "arrow.clockwise") }
                }
            }
    }
}

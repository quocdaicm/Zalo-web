import SwiftUI
import WebKit

struct WebContainer: UIViewRepresentable {
    let webView: WKWebView
    func makeUIView(context: Context) -> WKWebView { webView }
    func updateUIView(_ uiView: WKWebView, context: Context) {}
}

/// Màn hình web toàn màn hình, có thanh dưới để chuyển nhanh giữa các tài khoản.
struct WebScreen: View {
    @EnvironmentObject var store: AccountStore
    @Environment(\.dismiss) private var dismiss
    @State private var current: Account
    @State private var showDownloads = false
    @State private var showStyle = false

    init(start: Account) { _current = State(initialValue: start) }

    var body: some View {
        let web = store.webView(for: current)
        VStack(spacing: 0) {
            HStack(spacing: 12) {
                Button { dismiss() } label: {
                    Image(systemName: "chevron.down").font(.system(size: 17, weight: .semibold))
                }
                Text(current.name).font(.headline).lineLimit(1)
                Spacer()
                Button { showStyle = true } label: { Image(systemName: "paintbrush") }
                Button { store.browser = BrowserTarget(url: nil) } label: { Image(systemName: "globe") }
                Button { showDownloads = true } label: { Image(systemName: "arrow.down.circle") }
                Button {
                    if web.url == nil { web.load(URLRequest(url: AccountStore.zaloURL)) } else { web.reload() }
                } label: { Image(systemName: "arrow.clockwise") }
            }
            .padding(.horizontal, 16)
            .frame(height: 44)
            .background(.bar)

            banner

            WebContainer(webView: web)
                .id(current.id)

            switcher
        }
        .downloadToast(fromBrowser: false)
        .sheet(isPresented: $showDownloads) { DownloadsView() }
        .sheet(isPresented: $showStyle) { StyleSettingsView().presentationDetents([.medium, .large]) }
        .fullScreenCover(item: $store.browser) { BrowserScreen(target: $0, store: store) }
    }

    @ViewBuilder private var banner: some View {
        if !store.dismissedBanners.contains(current.id) {
            switch store.status[current.id] {
            case .offline:
                HStack(spacing: 10) {
                    ProgressView()
                    Text("Mất kết nối. Sẽ tự tải lại khi có mạng.").font(.footnote)
                    Spacer()
                    Button("Thử lại") { store.retryNow(current.id) }.font(.footnote.bold())
                    closeButton
                }
                .padding(.horizontal, 16).padding(.vertical, 8)
                .background(Color.gray.opacity(0.2))
            case .signedOut:
                HStack(spacing: 10) {
                    Image(systemName: "exclamationmark.triangle.fill").foregroundStyle(.orange)
                    Text("Phiên đăng nhập đã hết. Hãy đăng nhập lại.").font(.footnote)
                    Spacer()
                    Button("Đăng nhập lại") { store.relogin(current) }.font(.footnote.bold())
                    closeButton
                }
                .padding(.horizontal, 16).padding(.vertical, 8)
                .background(Color.orange.opacity(0.18))
            default:
                EmptyView()
            }
        }
    }

    private var closeButton: some View {
        Button { store.dismissBanner(current.id) } label: {
            Image(systemName: "xmark").font(.system(size: 13, weight: .bold))
                .frame(width: 32, height: 32).contentShape(Rectangle())
        }
        .foregroundStyle(.secondary)
        .accessibilityLabel("Ẩn thông báo")
    }

    private var switcher: some View {
        ScrollView(.horizontal, showsIndicators: false) {
            HStack(spacing: 18) {
                ForEach(store.accounts) { account in
                    Button { current = account } label: {
                        VStack(spacing: 4) {
                            Avatar(account: account, size: 40)
                                .overlay(alignment: .topTrailing) {
                                    UnreadBadge(count: store.unread[account.id] ?? 0).offset(x: 8, y: -6)
                                }
                                .overlay(alignment: .bottomTrailing) {
                                    StatusIcon(status: store.status[account.id]).offset(x: 6, y: 6)
                                }
                                .overlay(Circle().strokeBorder(Color.primary.opacity(account.id == current.id ? 0.9 : 0), lineWidth: 2).padding(-4))
                            Text(account.name).font(.caption2).lineLimit(1)
                                .foregroundStyle(account.id == current.id ? .primary : .secondary)
                        }
                        .frame(width: 60)
                    }
                    .buttonStyle(.plain)
                }
            }
            .padding(.horizontal, 16)
            .padding(.vertical, 8)
        }
        .background(.bar)
    }
}

import SwiftUI
import WebKit

struct BrowserTarget: Identifiable {
    let id = UUID()
    var url: URL?
}

struct DownloadEvent: Identifiable {
    let id = UUID()
    var url: URL?
    var error: String?
    var fromBrowser: Bool
}

enum Downloads {
    static var directory: URL {
        let dir = FileManager.default.urls(for: .documentDirectory, in: .userDomainMask)[0]
            .appendingPathComponent("Downloads", isDirectory: true)
        try? FileManager.default.createDirectory(at: dir, withIntermediateDirectories: true)
        return dir
    }

    /// Đường dẫn chưa bị trùng tên: "ten.pdf", "ten (1).pdf", ...
    static func uniqueURL(for suggested: String) -> URL {
        var name = suggested.replacingOccurrences(of: "/", with: "_")
            .trimmingCharacters(in: .whitespacesAndNewlines)
        if name.isEmpty { name = "tep-tai-ve" }
        let base = (name as NSString).deletingPathExtension
        let ext = (name as NSString).pathExtension
        var url = directory.appendingPathComponent(name)
        var n = 1
        while FileManager.default.fileExists(atPath: url.path) {
            let candidate = ext.isEmpty ? "\(base) (\(n))" : "\(base) (\(n)).\(ext)"
            url = directory.appendingPathComponent(candidate)
            n += 1
        }
        return url
    }

    static func list() -> [URL] {
        let keys: [URLResourceKey] = [.contentModificationDateKey]
        let urls = (try? FileManager.default.contentsOfDirectory(at: directory, includingPropertiesForKeys: keys)) ?? []
        return urls.sorted {
            let a = (try? $0.resourceValues(forKeys: Set(keys)).contentModificationDate) ?? .distantPast
            let b = (try? $1.resourceValues(forKeys: Set(keys)).contentModificationDate) ?? .distantPast
            return a > b
        }
    }
}

/// Xử lý điều hướng, cửa sổ mới, hộp thoại JavaScript và tải tệp cho một WebView.
/// `id == nil` nghĩa là WebView của trình duyệt trong ứng dụng.
@MainActor
final class WebDelegate: NSObject, WKNavigationDelegate, WKUIDelegate, WKDownloadDelegate {
    private weak var store: AccountStore?
    private let id: UUID?
    private var destinations: [ObjectIdentifier: URL] = [:]

    init(store: AccountStore, id: UUID?) { self.store = store; self.id = id }

    private static let zaloSuffixes = ["zalo.me", "zaloapp.com", "zdn.vn", "zadn.vn", "zalo.cloud"]

    static func isZalo(_ url: URL) -> Bool {
        guard let host = url.host?.lowercased() else { return false }
        return zaloSuffixes.contains { host == $0 || host.hasSuffix("." + $0) }
    }

    // MARK: Điều hướng

    func webView(_ webView: WKWebView, decidePolicyFor navigationAction: WKNavigationAction,
                 decisionHandler: @escaping (WKNavigationActionPolicy) -> Void) {
        if navigationAction.shouldPerformDownload { decisionHandler(.download); return }

        if let url = navigationAction.request.url, let scheme = url.scheme?.lowercased() {
            if !["http", "https", "about", "blob", "data", "file"].contains(scheme) {
                // tel:, mailto:, zalo:... giao cho hệ thống xử lý
                if navigationAction.navigationType == .linkActivated { UIApplication.shared.open(url) }
                decisionHandler(.cancel)
                return
            }
            // Trong cửa sổ tài khoản, liên kết ra ngoài Zalo mở bằng trình duyệt trong ứng dụng.
            if id != nil, navigationAction.navigationType == .linkActivated,
               scheme.hasPrefix("http"), !Self.isZalo(url) {
                store?.openInBrowser(url)
                decisionHandler(.cancel)
                return
            }
        }
        decisionHandler(.allow)
    }

    func webView(_ webView: WKWebView, decidePolicyFor navigationResponse: WKNavigationResponse,
                 decisionHandler: @escaping (WKNavigationResponsePolicy) -> Void) {
        if let http = navigationResponse.response as? HTTPURLResponse,
           let disposition = http.value(forHTTPHeaderField: "Content-Disposition")?.lowercased(),
           disposition.hasPrefix("attachment") {
            decisionHandler(.download)
        } else if navigationResponse.isForMainFrame, !navigationResponse.canShowMIMEType {
            decisionHandler(.download)
        } else {
            decisionHandler(.allow)
        }
    }

    func webView(_ webView: WKWebView, navigationAction: WKNavigationAction, didBecome download: WKDownload) {
        download.delegate = self
    }

    func webView(_ webView: WKWebView, navigationResponse: WKNavigationResponse, didBecome download: WKDownload) {
        download.delegate = self
    }

    // MARK: Trạng thái tải trang (chỉ cho cửa sổ tài khoản)

    func webView(_ webView: WKWebView, didFailProvisionalNavigation navigation: WKNavigation!, withError error: Error) {
        if let id { store?.loadFailed(id, error) }
    }
    func webView(_ webView: WKWebView, didFail navigation: WKNavigation!, withError error: Error) {
        if let id { store?.loadFailed(id, error) }
    }
    func webView(_ webView: WKWebView, didCommit navigation: WKNavigation!) {
        if let id { store?.loadSucceeded(id) }
    }
    func webView(_ webView: WKWebView, didFinish navigation: WKNavigation!) {
        if let id { store?.loadSucceeded(id) }
    }
    func webViewWebContentProcessDidTerminate(_ webView: WKWebView) {
        if let id { store?.contentProcessTerminated(id) } else { webView.reload() }
    }

    // MARK: Cửa sổ mới và hộp thoại JavaScript

    func webView(_ webView: WKWebView, createWebViewWith configuration: WKWebViewConfiguration,
                 for navigationAction: WKNavigationAction, windowFeatures: WKWindowFeatures) -> WKWebView? {
        guard let url = navigationAction.request.url else { return nil }
        if id == nil {
            webView.load(navigationAction.request)   // trình duyệt: mở ngay trong cùng cửa sổ
        } else if let scheme = url.scheme?.lowercased(), scheme.hasPrefix("http") {
            store?.openInBrowser(url)
        }
        return nil
    }

    func webView(_ webView: WKWebView, runJavaScriptAlertPanelWithMessage message: String,
                 initiatedByFrame frame: WKFrameInfo, completionHandler: @escaping () -> Void) {
        let alert = UIAlertController(title: nil, message: message, preferredStyle: .alert)
        alert.addAction(UIAlertAction(title: "OK", style: .default) { _ in completionHandler() })
        present(alert, orElse: completionHandler)
    }

    func webView(_ webView: WKWebView, runJavaScriptConfirmPanelWithMessage message: String,
                 initiatedByFrame frame: WKFrameInfo, completionHandler: @escaping (Bool) -> Void) {
        let alert = UIAlertController(title: nil, message: message, preferredStyle: .alert)
        alert.addAction(UIAlertAction(title: "Hủy", style: .cancel) { _ in completionHandler(false) })
        alert.addAction(UIAlertAction(title: "OK", style: .default) { _ in completionHandler(true) })
        present(alert, orElse: { completionHandler(false) })
    }

    private func present(_ alert: UIAlertController, orElse fallback: () -> Void) {
        let scene = UIApplication.shared.connectedScenes
            .compactMap { $0 as? UIWindowScene }
            .first { $0.activationState == .foregroundActive }
        var top = scene?.keyWindow?.rootViewController
        while let next = top?.presentedViewController { top = next }
        if let top { top.present(alert, animated: true) } else { fallback() }
    }

    // MARK: Tải tệp

    func download(_ download: WKDownload, decideDestinationUsing response: URLResponse,
                  suggestedFilename: String, completionHandler: @escaping (URL?) -> Void) {
        let dest = Downloads.uniqueURL(for: suggestedFilename)
        destinations[ObjectIdentifier(download)] = dest
        completionHandler(dest)
    }

    func downloadDidFinish(_ download: WKDownload) {
        if let url = destinations.removeValue(forKey: ObjectIdentifier(download)) {
            store?.downloadFinished(url, fromBrowser: id == nil)
        }
    }

    func download(_ download: WKDownload, didFailWithError error: Error, resumeData: Data?) {
        if let url = destinations.removeValue(forKey: ObjectIdentifier(download)) {
            try? FileManager.default.removeItem(at: url)
        }
        store?.downloadFailed(error, fromBrowser: id == nil)
    }
}

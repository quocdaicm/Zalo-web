import SwiftUI
import WebKit

/// CSS tiêm vào trang Zalo Web. Các mục có sẵn không phụ thuộc vào tên lớp của Zalo;
/// phần "CSS tùy chỉnh" để bạn tự thêm quy tắc riêng.
struct WebStyle: Codable, Equatable {
    var hideScrollbars = true
    var noTapHighlight = true
    var noOverscroll = false
    var invertDark = false
    var custom = ""

    private static let key = "webStyle.v1"

    static func load() -> WebStyle {
        guard let data = UserDefaults.standard.data(forKey: key),
              let s = try? JSONDecoder().decode(WebStyle.self, from: data) else { return WebStyle() }
        return s
    }

    func save() {
        if let data = try? JSONEncoder().encode(self) { UserDefaults.standard.set(data, forKey: Self.key) }
    }

    var css: String {
        var parts: [String] = []
        if hideScrollbars { parts.append("::-webkit-scrollbar{display:none!important}") }
        if noTapHighlight { parts.append("*{-webkit-tap-highlight-color:transparent!important}html{touch-action:manipulation}") }
        if noOverscroll { parts.append("html,body{overscroll-behavior:none!important}") }
        if invertDark {
            parts.append("""
            html{filter:invert(1) hue-rotate(180deg)!important;background:#fff}
            img,video,canvas,picture{filter:invert(1) hue-rotate(180deg)!important}
            """)
        }
        if !custom.isEmpty { parts.append(custom) }
        return parts.joined(separator: "\n")
    }

    /// Mã JavaScript tạo hoặc thay thẻ <style id="zws-style">.
    var script: String {
        let json = (try? JSONEncoder().encode(css)).flatMap { String(data: $0, encoding: .utf8) } ?? "\"\""
        return """
        (function(){var css=\(json);var s=document.getElementById('zws-style');
        if(!s){s=document.createElement('style');s.id='zws-style';(document.head||document.documentElement).appendChild(s);}
        s.textContent=css;})();
        """
    }
}

struct StyleSettingsView: View {
    @EnvironmentObject var store: AccountStore
    @Environment(\.dismiss) private var dismiss

    var body: some View {
        NavigationStack {
            Form {
                Section("Có sẵn") {
                    Toggle("Ẩn thanh cuộn", isOn: $store.style.hideScrollbars)
                    Toggle("Bỏ viền sáng khi chạm", isOn: $store.style.noTapHighlight)
                    Toggle("Chặn kéo giãn khi cuộn", isOn: $store.style.noOverscroll)
                    Toggle("Chế độ tối (thử nghiệm)", isOn: $store.style.invertDark)
                }
                Section {
                    TextEditor(text: $store.style.custom)
                        .font(.system(.footnote, design: .monospaced))
                        .textInputAutocapitalization(.never)
                        .autocorrectionDisabled()
                        .frame(minHeight: 140)
                } header: {
                    Text("CSS tùy chỉnh")
                } footer: {
                    Text("Áp dụng ngay cho mọi tài khoản. Chế độ tối đảo màu cả trang, ảnh và video được đảo lại; nếu thấy màu lạ, hãy tắt đi.")
                }
                Section {
                    Button("Đặt lại mặc định", role: .destructive) { store.style = WebStyle() }
                }
            }
            .navigationTitle("Giao diện web")
            .navigationBarTitleDisplayMode(.inline)
            .toolbar { ToolbarItem(placement: .topBarTrailing) { Button("Xong") { dismiss() } } }
        }
    }
}

import SwiftUI

@main
struct ZaloWebApp: App {
    @StateObject private var store = AccountStore()

    var body: some Scene {
        WindowGroup {
            AccountListView()
                .environmentObject(store)
        }
    }
}
